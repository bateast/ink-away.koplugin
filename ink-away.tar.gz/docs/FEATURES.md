# Ink Away: every feature

The full reference. The [README](../README.md) has the short version.



## Toolbar

<img src="../assets/readme-toolbar.svg" alt="The toolbar: Pen, Eraser, Shapes, Text, Image, Lasso, Undo, Redo, Settings, Library, File and Exit">

* File holds rename, duplicate, export, new drawing and new notebook. Zoom is the floating +/− control in the corner, with the Pan button just above it: tap it to pan, and again to go back to the tool you had.


## Write and draw

| | |
|---|---|
| **Pens** | Fineliner, Ballpoint, Fountain, Calligraphy with its own nib angle, Pencil, Highlighter, Marker, Watercolor and Smudge, each with size, opacity, greys everywhere and full colour on colour screens. The highlighter, marker and watercolor blend with the page, and text stays black under the highlighter. A brush maker makes your own. |
| **Pen case** | Up to 20 saved pens, each shown at its real size, with a floating strip of your first ones. |
| **Pen pressure** | On the Kindle Scribe and Kobo readers with a stylus the line can follow how hard you press. It is a Beta, turned on in Pen and input. |
| **Hold to straighten** | Hold the pen still at the end of a stroke and a rough line, box, ellipse or triangle snaps clean. Writing is left alone. |
| **Shapes** | Lines, curves, single and double arrows, rectangles, ellipses and triangles, filled or outlined, snapped to the grid or to 45°. A paint bucket fills an area in one tap. |
| **Eraser** | Clears ink back to transparent, or removes whole strokes. It leaves pictures alone unless you ask, and can spare text too. |
| **Text** | Text boxes in any installed font, with bold, italic, underline, sizes, alignment, line spacing, lists and checklists you tick with a tap, snapped to a notebook's lines. On colour screens, coloured text and highlights in yellow, orange, blue, green, pink or your own colours. Turn a box to any angle, or stand it on end for a book's margin. A Bluetooth or USB keyboard that KOReader has set up types into it too. |
| **Pictures** | From a file or found online (Wikimedia or Openverse), then moved, resized, turned and cut out of their background. A picture can also sit behind a drawing to trace over. |
| **Symmetry** | Draw mirrored left to right, top to bottom, or four ways. |

## Layers

Sketch, ink and colour each on a layer of its own, as in a desktop or tablet drawing app.

| | |
|---|---|
| **Up to five** | File, Layers turns them on, and what you drew so far becomes the first layer. Drawings start without them, so nothing changes until you want them. |
| **The strip** | A small strip at the right, shown only while layers are on. Tap a layer to draw on it; tap it again to show or hide, rename, move, merge down or delete it. |
| **Colour under line art** | A stroke on a lower layer stays under the layers above it while you draw. The eraser, the lasso and the paint bucket only touch the layer you are on. |
| **Merge when done** | Merge a layer into the one under it, or turn layers off to merge them all into one drawing. Hidden layers stay out of exports. |
| **Light on your reader** | No layer is kept as a picture of its own, so drawing on layers is as fast as on a plain page and takes little memory. |

## Select and edit

| | |
|---|---|
| **Lasso** | Loop writing, shapes, pictures and text, then move, resize, turn, flip, recolour, change opacity or size, duplicate or delete them, or cut, copy and paste to any page of any notebook or drawing. With Pan, a touch picks a shape or picture. |
| **Convert to text** | Lassoed handwriting is read on the device (English letters and digits), shown to check and fix, then becomes a text box with Convert, or stays as it is with Cancel. One undo brings the writing back. It can also use an online service, below. |
| **Undo and redo** | From the toolbar, or with two fingers (see Gestures). |

## Convert to text online (experimental)

For handwriting the reader cannot read well, Convert to text can use an online
service of your own instead. Tap the Text tool twice to open its sheet and switch on **Convert
to text online**, then set its **Address**, **Key** and **Model**. The service has
to take pictures through the OpenAI-style Chat Completions API, for example
`https://your-provider.example/v1` with the model `paddleocr-vl`. The address can
also be the full `/chat/completions` one. The key is never shown, but it is kept
unencrypted in KOReader's settings, not in notebooks or exports. Switching it off
hides the fields, keeps what you typed, and goes back to reading on the reader.

With Wi-Fi on, lasso the writing and choose **Convert to text**. Only the selected
writing is sent, as a black-on-white picture with erased parts left out; the page,
pictures and other writing are not. What comes back is shown to check and fix
before **Convert**. If the service fails, the writing stays as it was.

Only HTTPS addresses with a valid certificate work; plain HTTP and redirects are
refused. One request runs at a time, for up to 90 seconds, with pictures up to
4 megapixels. Stop drops the answer, though the service may still finish the request.
Tested on a Kobo Libra Colour with KOReader 2026.07.1 and PaddleOCR-VL; how well it
reads depends on the service, the model and the handwriting.

## Notebooks and PDFs

| | |
|---|---|
| **Notebooks** | As many pages as you like, each with a title, a star and its own paper. Insert, duplicate and move pages, or save one as a template to start new pages from. |
| **Papers and planners** | Blank, lined, grid, dotted, isometric, margin ruled and Cornell, plus handwriting practice, checklist, two columns, storyboard, music, daily, weekly, week columns, monthly, meeting notes and a habit tracker. You set the line spacing and strength, and drawings can use any of them as a guide. |
| **Paper colours** | Twelve papers on colour screens, from cream and legal pad to kraft, blueprint and chalkboard, and white or black on grey ones. Black ink and text turn white on a dark paper, and exports come out on the same paper. |
| **Annotate PDFs** | Open any PDF as a notebook and write on its pages. |
| **Links and contents** | Make anything a link to a page of this or another notebook, with a Back button to return; tap a link with Pan, or with a finger while palm rejection is on, to follow it. A contents page lists the titled pages, each one a link, and Go to the contents page in the page menu (or on a gesture) gets you there. |

## Write on your books

| | |
|---|---|
| **Any book** | EPUB, MOBI, FB2, PDF, DjVu, CBZ and every other format KOReader opens. Pen, eraser, shapes, text and pictures work right on the page. |
| **Ink follows the text** | On a reflowing book each stroke is anchored to the words beside it, so it stays with them when you change the font size, margins or orientation. On PDFs and comics it keeps its place on the page. |
| **Smart highlighter** | A highlighter stroke over text becomes KOReader's own highlight in the pen's colour and shows in your highlights list. Strokes that wobble or run into the margin still snap; over empty space it stays ink. The eraser takes highlights away like ink, and a long press on one offers to remove it. |
| **Book notes** | A notebook for each book with a page for each chapter, in a window over the page that expands to full screen. |
| **Toolbar** | On any side of the screen, and it folds away. It can also fit in the book's margin, clear of the text. |
| **Kept with the book** | Annotations live beside the book's own KOReader data and follow it when it is moved or renamed. Deleting them puts them in Ink Away's trash for 30 days. |

## Organize and find

|             |                                                                                                                                          |
| ----------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| **Library** | Every drawing and notebook is a file that saves itself. Folders, thumbnails, rename, move, duplicate and delete, all without a computer. Pictures in a folder show too, to view full screen. |
| **Folder colours** | Give a folder one of twelve colours and an icon from your KOReader, your own koreader/icons folder included, so you spot it at a glance. |
| **Browse**  | A folder's notebooks as coloured tabs beside their pages, with a starred-only view. Move or copy pages to any notebook.                   |
| **Search**  | By name, or by the text inside pages, handwriting turned into text included.                                                             |
| **Trash**   | Deleted notebooks, drawings, folders and pages wait 30 days and go back exactly where they were if restored.                             |

<details>
<summary><b>Screenshot</b></summary>
<br>
<a href="../assets/screenshots/library-folder-look.png"><img src="../assets/screenshots/library-folder-look.png" alt="Folder colour and icon" width="50%"></a><br><sub>Hold a folder in the library for its colour and icon.</sub>
</details>

## On Bookshelf

With the [Bookshelf](https://github.com/AndyHazz/bookshelf.koplugin) plugin installed, your notebooks and drawings can each have a shelf of their own.

| | |
|---|---|
| **Notebooks shelf** | Every notebook stands face out on its cover: Front page, Hardcover, Composition book, Reporter pad, Kraft with window or Legal pad, in its tab colour or one you pick. |
| **Drawings shelf** | Every drawing hangs in a frame, from Gilded Baroque, Louis XVI and Art Deco to Museum Mat, Painted Box, Canvas Wrap and Instant Photo, each in a few finishes. A new drawing gets one at random. |
| **Tap and hold** | A tap opens a notebook or drawing in Ink Away. A long press picks its cover or frame, and so does its menu in the library. |
| **Quick** | A cover is a picture Ink Away keeps as you close the notebook or drawing, made again only when it changed, so the shelf opens at once and never draws your strokes again. |

<details>
<summary><b>Screenshots</b></summary>
<br>
<table>
  <tr>
    <td width="50%" valign="top"><a href="../assets/screenshots/bookshelf-notebooks.png"><img src="../assets/screenshots/bookshelf-notebooks.png" alt="Notebooks shelf"></a><br><sub>Notebooks on a Bookshelf shelf, each in its cover style and colour.</sub></td>
    <td width="50%" valign="top"><a href="../assets/screenshots/bookshelf-drawings.png"><img src="../assets/screenshots/bookshelf-drawings.png" alt="Drawings shelf"></a><br><sub>Drawings on a Bookshelf shelf, each in its own frame.</sub></td>
  </tr>
</table>
<table>
  <tr>
    <td width="33%" valign="top"><a href="../assets/screenshots/bookshelf-covers.png"><img src="../assets/screenshots/bookshelf-covers.png" alt="Cover styles"></a><br><sub>Hold a notebook to pick its cover style, or its colour.</sub></td>
    <td width="33%" valign="top"><a href="../assets/screenshots/bookshelf-frames.png"><img src="../assets/screenshots/bookshelf-frames.png" alt="Frames"></a><br><sub>Hold a drawing to pick its frame from twelve, shown on the drawing itself.</sub></td>
    <td width="33%" valign="top"><a href="../assets/screenshots/bookshelf-finishes.png"><img src="../assets/screenshots/bookshelf-finishes.png" alt="Finishes"></a><br><sub>Each frame comes in a few finishes, here gold, antique gold and silver gilt.</sub></td>
  </tr>
</table>
</details>

## Export

| | |
|---|---|
| **PNG** | Transparent or white, at your screen size, of the whole page or an area you pick, with or without the grid. A notebook or a book can save the page shown, all pages, the ones with ink or a range, one PNG each in a folder of their own. |
| **PDF** | A notebook, some of its pages, or a whole folder at once, with bookmarks for titled pages, working links and page numbers, on white or sandpaper paper. |
| **Editable PDF** | For a PDF notebook or a PDF you annotate while reading: a copy of the original with your ink and highlights added as real annotations. The text stays selectable, the file stays about the size it was, and any PDF viewer can edit or remove them. Whatever a PDF annotation can't hold (text boxes, pictures, fills) is listed first. You choose to leave it out, or to keep those pages' ink as a small picture over just those pages, while every other page stays editable. |
| **A book as a PDF** | In the annotation mode, Export (in Book ink settings, or Tools, Ink Away) saves an EPUB, MOBI or any other book as a fixed PDF, laid out as you read it now, with your pen strokes, shapes, placed pictures and highlights exactly where they are on the screen, in the colours you chose. Each page carries its text under the picture, so the PDF can be searched, selected and copied in any PDF viewer. Or save the pages with ink as PNGs, one file each in a folder, or only your ink on white pages. A progress bar shows the way, and Stop ends the export and deletes what it wrote. |
| **Bookshelf ornament** | With the Bookshelf plugin installed, save a drawing straight into its ornaments. |
| **Phone or computer (Wi-Fi)** | Scan a QR code on the reader with any phone or computer on the same Wi-Fi to download your notebooks and drawings as PDF, PNG or Ink Away files in its browser, or to send PDFs (they become notebooks) and pictures (made smaller on the phone if you like) to Library › Imported. Nothing to install, no account, and nothing leaves your home network. |

## Pen, screen and colour

| | |
|---|---|
| **Dark mode** | Light, Dark or following KOReader's night mode, for Ink Away's toolbars, menus and library. Your page and colours are never changed. |
| **Palm rejection** | Rest your hand on the screen while the pen writes (on by default on Kindle Scribe and reMarkable). The pen can still tap the toolbar and menus. |
| **Stylus buttons** | The eraser end erases, and holding the side button makes the pen a highlighter, on pens that have them. Both work while reading too, without opening the annotation mode. You can set them to anything else. |
| **Colour screens** | A theme colour, Ink Away green by default, and colour ink that shows as you draw. In KOReader's night mode ink keeps its colour: blue stays blue, and dark ink turns light to read on the dark page. |
| **E-ink** | Light refreshes while you draw, an optional clean-up refresh every few strokes, a full refresh whenever you like from Settings or a gesture, portrait or landscape, and bars that fold away for more room. |

## Help and updates

| | |
|---|---|
| **Guide** | Short cards on what a glance doesn't show, by topic, each with "Show me". |
| **Updates** | Settings, Updates shows the latest release and any newer prerelease apart from it, with their notes. It installs them after checking the download. Once a day, only on Wi-Fi that is already on, Ink Away looks by itself and puts a dot on the Settings button when there is something new. |
| **Test pen and touch** | Shows how your pen, its buttons and your hand arrive, handy for bug reports. |

## Gestures

| Gesture | What it does |
|---|---|
| Two-finger tap | Undo |
| Two-finger double tap | Redo |
| Two-finger swipe left or right | Turn a notebook's page |
| Long two-finger swipe up | Open Browse in a notebook, or the Library from a drawing |
| Long two-finger swipe down | Refresh the screen, clearing ghosting and anything a quick refresh missed |
| Page turn buttons | Turn a notebook's page, or the book's in annotation mode |
| Pinch | Zoom |
| Two-finger drag | Move around the page |
| Hold Prev or Next | Jump to the first or last page |
| Swipe down the right edge (in a book) | Annotate the book |
| Swipe up the right edge | The book's notes, or Ink Away outside a book |

Ink Away sets up the two book gestures for you where they are free, and tells you which you got; a reader that already uses the right edge gets diagonal swipes with two fingers instead. Every gesture and pen button can be changed in Settings, Gestures and pen buttons.

With palm rejection on, **Finger on the page** in the pen settings decides what a finger does while the pen writes:
* **Navigate** (scroll, turn pages, hold a picture or shape for its menu) or
* **Nothing**. A finger never draws then, so a resting hand can't either.


## Getting started in detail

<summary><b>Getting started</b></summary>

1. **To draw or take notes, swipe up the right edge** in KOReader's file browser. The first time, Ink Away opens on a blank drawing; File, New notebook gives you lined, grid or planner pages instead.
2. **To write on a book, open it and swipe down the right edge.** The toolbar comes up and you write right on the page. Close with ✕ and your ink stays with the book.
3. **If your reader uses the right edge for its light,** these are two finger swipes instead: from the bottom right corner toward the top left to open Ink Away, and from the top right toward the bottom left on a book.
4. **Tap a tool, then tap it again** for its settings: size, colour, kind of pen and so on.
5. **Not sure how something works?** The Guide button in Settings has a short card for it, with "Show me".
6. **Want different gestures?** Use KOReader's Settings, Taps and gestures, Gesture manager. A book has its own gestures, apart from the file browser's, so open a book first to change the book ones. The actions are "Ink Away: annotate the book" and "Ink Away: book notes", and "Open Ink Away" under General.


## Notes


- Palm rejection needs KOReader 2026.07+.
- Drawings and notebooks are kept in an "ink away" folder and saved automatically; exported PNGs and PDFs go to "ink away/exports" unless you pick another folder. Work from older versions' "drawing projects" and "notebook projects" folders moves into the "ink away" folder on the first start.
- Settings → "When Ink Away opens" picks what you see first: the last document, the library, or Notebooks (the notebook browser on your last notebook, for note-taking).

## How it's made



## More screenshots


<table>
  <tr>
    <td width="33%" valign="top"><a href="../assets/screenshots/browse.png"><img src="../assets/screenshots/browse.png" alt="Notebooks in a folder"></a><br><sub>A folder's notebooks as coloured tabs, with every page at a glance.</sub></td>
    <td width="33%" valign="top"><a href="../assets/screenshots/library.png"><img src="../assets/screenshots/library.png" alt="Library"></a><br><sub>The library: folders, notebooks and drawings, saved as you go.</sub></td>
    <td width="33%" valign="top"><a href="../assets/screenshots/search.png"><img src="../assets/screenshots/search.png" alt="Search"></a><br><sub>Search names, or the typed and converted text inside pages.</sub></td>
  </tr>
  <tr>
    <td width="33%" valign="top"><a href="../assets/screenshots/layers.gif"><img src="../assets/screenshots/layers.gif" alt="Layers"></a><br><sub>Layers: colour under your line art, then hide or show each layer from the strip.</sub></td>
    <td width="33%" valign="top"><a href="../assets/screenshots/lasso-selection.png"><img src="../assets/screenshots/lasso-selection.png" alt="Lasso selection"></a><br><sub>Lasso anything to move, resize, rotate, recolour or link it, or turn writing into text.</sub></td>
    <td width="33%" valign="top"><a href="../assets/screenshots/pdf-annotation.png"><img src="../assets/screenshots/pdf-annotation.png" alt="PDF annotation"></a><br><sub>Open a PDF as a notebook and write on it, then export it with your ink.</sub></td>
  </tr>
  <tr>
    <td width="33%" valign="top"><a href="../assets/screenshots/pens.png"><img src="../assets/screenshots/pens.png" alt="Pen case"></a><br><sub>Pens with pressure, watercolor that blends and smudge that mixes colours like paint.</sub></td>
    <td width="33%" valign="top"><a href="../assets/screenshots/dark-mode.png"><img src="../assets/screenshots/dark-mode.png" alt="Dark mode"></a><br><sub>Dark mode for the toolbars and menus, here over chalkboard paper.</sub></td>
    <td width="33%" valign="top"><a href="../assets/screenshots/paper-colours.png"><img src="../assets/screenshots/paper-colours.png" alt="Paper colours"></a><br><sub>Twelve paper colours, from cream and legal pad to kraft and blueprint.</sub></td>
  </tr>
</table>

<details>
<summary><b>More screenshots</b></summary>
<br>
<table>
  <tr>
    <td width="25%" valign="top"><a href="../assets/screenshots/guide.png"><img src="../assets/screenshots/guide.png" alt="Guide"></a><br><sub>A guide to what a glance doesn't show, each card with "Show me".</sub></td>
    <td width="25%" valign="top"><a href="../assets/screenshots/updates.png"><img src="../assets/screenshots/updates.png" alt="Updates"></a><br><sub>Updates from inside Ink Away, with the release notes.</sub></td>
    <td width="25%" valign="top"><a href="../assets/screenshots/gestures.png"><img src="../assets/screenshots/gestures.png" alt="Gestures and pen buttons"></a><br><sub>Choose what each gesture and pen button does.</sub></td>
    <td width="25%" valign="top"><a href="../assets/screenshots/contents-page.png"><img src="../assets/screenshots/contents-page.png" alt="Contents page"></a><br><sub>A contents page that links to your titled pages.</sub></td>
  </tr>
</table>
</details>
